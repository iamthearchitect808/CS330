 #include <iostream>				// cout, cerr
#include <cstdlib>				// EXIT_FAILURE
#include <include/GL/glew.h>	// GLEW library
#include <include/GLFW/glfw3.h> // GLFW library
#include <C:\\Users\Natha\Downloads\OpenGLSample\OpenGLSample\OpenGLSample\Sphere.h>
#define STB_IMAGE_IMPLEMENTATION
#include <C:\\Users\Natha\Downloads\OpenGLSample\OpenGLSample\OpenGLSample\stb_image.h>

// GLM Math Header inclusions
#include <cmath>
#include <vector>
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include <C:\\Users\Natha\Downloads\OpenGLSample\OpenGLSample\OpenGLSample\camera.h>


using namespace std;  // Standard namespace
#define PI 3.14159265359

/* Shader program Macro*/
#ifndef GLSL
#define GLSL(Version, Source) "#version " #Version " core \n" #Source
#endif

namespace
{
	const char* const WINDOW_TITLE = "Nate Holcombe Module 7 Project"; // Window title

	// window settings
	const int WINDOW_WIDTH = 800;
	const int WINDOW_HEIGHT = 600;

	// Stores the GL data relative to a given mesh
	struct GLMesh
	{
		GLuint vao;       // Handle for a vertex array object
		GLuint vbo;   // Handle for the vertex buffer objects
		GLuint ebo;  // Handle for the element buffer object
		GLuint nVertices;  // Number of indices of the mesh
		GLuint nIndices;   // Number of indices of the mesh
	};
	

	// Main GLFW window
	GLFWwindow* gWindow = nullptr;
	// Floor plane mesh data
	GLMesh floorMesh;
	// Bench feet mesh data
	GLMesh feetMesh;
	// Back foot mesh data
	GLMesh backfootMesh;
	// Bench legs mesh data
	GLMesh legsMesh;
	GLMesh backlegMesh;
	// Bench buttpad mesh data
	GLMesh buttpadMesh;
	// Bench backpad mesh data
	GLMesh backpadMesh;
	// Exercise ball (and light sources) mesh data
	GLMesh sphereMesh;
	// Texture id
	GLuint gTextureId, gTextureId1, gTextureId2; 
	glm::vec2 gUVScale(5.0f, 5.0f);
	GLint gTexWrapMode = GL_LINEAR;
	// Textures
	GLuint floorTex, feetTex, padTex; // add sphereTex;
	// Shader programs
	GLuint gProgramId;
	GLuint gLampProgramId;
	GLuint gSecLightProgramId;


	// camera
	Camera gCamera(glm::vec3(0.0f, 0.0f, 3.0f));
	float gLastX = WINDOW_WIDTH / 2.0f;
	float gLastY = WINDOW_HEIGHT / 2.0f;
	bool gFirstMouse = true;


	// timing
	float gDeltaTime = 0.0f; // time between current frame and last frame
	float gLastFrame = 0.0f;


	// Bench components and light color
	glm::vec3 gObjectColor(1.0f, 0.2f, 0.0f);
	glm::vec3 gLightColor(0.5f, 1.0f, 0.5f);
	glm::vec3 gSecLightColor(1.0f, 0.5f, 0.5f);


	// Primary light position and scale
	glm::vec3 gLightPosition(1.5f, 1.0f, 2.0f);
	glm::vec3 gLightScale(1.0f);


	// Secondary light position and scale
	glm::vec3 gSecLightPosition(-1.5f, 0.7f, -1.0f);
	glm::vec3 gSecLightScale(1.0f);
}


/* User-defined Function prototypes to:
*  initialize the program, set the window size,
*  redraw graphics on the window when resized,
*  and render graphics on the screen
*/
bool UInitialize(int, char* [], GLFWwindow** window);
void UResizeWindow(GLFWwindow* window, int width, int height);
void UProcessInput(GLFWwindow* window);
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos);
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset);
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods);
bool UCreateMeshF(GLMesh& floorMesh);
bool UCreateMesh(GLMesh& feetMesh);
bool UCreateMeshB(GLMesh& backfootMesh);
bool UCreateMesh2(GLMesh& legsMesh);
bool UCreateMesh2B(GLMesh& backlegMesh);
bool UCreateMesh3(GLMesh& buttpadMesh);
bool UCreateMesh4(GLMesh& backpadMesh);
bool UCreateMesh5(GLMesh& sphereMesh);
void UDestroyMeshF(GLMesh& floorMesh);
void UDestroyMesh(GLMesh& feetMesh);
void UDestroyMeshB(GLMesh& backfootMesh);
void UDestroyMesh2(GLMesh& legsMesh);
void UDestroyMesh2B(GLMesh& backlegMesh);
void UDestroyMesh3(GLMesh& buttpadMesh);
void UDestroyMesh4(GLMesh& backpadMesh);
void UDestroyMesh5(GLMesh& sphereMesh);
bool UCreateTexture(const char* filename, GLuint& textureId);
void UDestroyTexture(GLuint textureId);
void URender();
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId);
void UDestroyShaderProgram(GLuint programId);
void UpdateProjection(GLboolean toggle = GL_FALSE);


/* Vertex Shader Source Code*/
const GLchar* vertexShaderSource = GLSL(440,
	layout(location = 0) in vec3 position; // Vertex data from Vertex Attrib Pointer 0
    layout(location = 1) in vec3 normal;  // Vertex position 1 for normals
    layout(location = 2) in vec2 textureCoordinate; // texture data from Vertex Attrib Pointer 1
	layout(location = 3) in float a_texIndex;

	out vec3 vertexNormal;  // For outgoing normals to fragment shader
	out vec3 vertexFragmentPos;  // For outgoing color or pixels to fragment shader
	out vec2 vertexTextureCoordinate; // variable to transfer color data to the fragment shader
	out float v_texIndex;


	// Global variables for the transform matrices
	uniform mat4 model;
	uniform mat4 view;
	uniform mat4 projection;


	void main()
	{
		gl_Position = projection * view * model * vec4(position, 1.0f); // transforms vertices to clip coordinates
		vertexFragmentPos = vec3(model * vec4(position, 1.0f));  // Gets fragment or pixel position in world space only
		vertexNormal = mat3(transpose(inverse(model))) * normal;  // Gets normal vectors in world space only and excludes normal translation properties
		vertexTextureCoordinate = textureCoordinate; // references incoming color data
		v_texIndex = a_texIndex;
	}
);

/* Fragment Shader Source Code*/
const GLchar* fragmentShaderSource = GLSL(440,

	in vec3 vertexNormal;   // For incoming normals
    in vec3 vertexFragmentPos;  // For incoming fragment position
	in vec2 vertexTextureCoordinate; // Variable to hold incoming color data from vertex shader
    in float v_texIndex;

	out vec4 fragmentColor;


	// Uniform or Global variables for object color, light color, light position, and camera/view position
	uniform vec3 objectColor;
	uniform vec3 lightColor;
	uniform vec3 lightPos;
	uniform vec3 secLightColor;
	uniform vec3 secLightPos;
	uniform vec3 viewPosition;
	uniform sampler2D uTextures[3];
	uniform vec2 uvScale;


	void main()
	{
		// Phong lighting model calculations to generate ambient, diffuse, and specular components

		// Calculate ambient lighting
		float ambientStrength = 0.10f;  // Set ambient or global lighting strength
		vec3 ambient = ambientStrength * lightColor;  // Generate ambient light color

		// Calculate diffuse lighting for primary
		vec3 norm = normalize(vertexNormal);
		vec3 lightDirection = normalize(lightPos - vertexFragmentPos); // Calculate distance (light direction between light source and fragments/pixels on shapes
		float impact = max(dot(norm, lightDirection), 0.0);  // Calculate diffuse impact by generating dot product of normal and light
		vec3 diffuse = impact * lightColor;  // Generate diffuse light color

		// Calculate diffuse lighting for secondary
		vec3 secNorm = normalize(vertexNormal);
		vec3 secLightDirection = normalize(secLightPos - vertexFragmentPos); // Calculate distance between secondary light source and fragment/pixels on pyramid
		float secLightImpact = max(dot(norm, secLightDirection), 0.0);  // Calculate diffuse impact by generating dot product of normal and secondary light
		vec3 secLightDiffuse = secLightImpact * secLightColor;  // Generate diffuse secondary light color

		// Calculate Specular lighting for primary light
		float specularIntensity = 0.8f;  // Set specular light strength
		float highlightSize = 16.0f;  // Set specular light size
		vec3 viewDir = normalize(viewPosition - vertexFragmentPos);  // Calculate view direction
		vec3 reflectDir = reflect(-lightDirection, norm); // Calculate reflection vector

		//Calculate Specular lighting for secondary light
		//float secLightSpecIntensity = 0.8f;  // Set specular light strength
		//float secLightHighlightSize = 16.0f;  // Set specular light size
		vec3 secViewDir = normalize(viewPosition - vertexFragmentPos);  // Calculate view direction
		vec3 secReflectDir = reflect(-secLightDirection, norm);  // Calculate reflection vector

		// Calculate specular component for primary light
		float specularComponent = pow(max(dot(viewDir, reflectDir), 0.0), highlightSize);
		vec3 specular = specularIntensity * specularComponent * lightColor;

		// Calculate specular component for secondary light
		float secSpecularComponent = pow(max(dot(secViewDir, secReflectDir), 0.0), highlightSize);
		vec3 secLightSpecular = specularIntensity * secSpecularComponent * secLightColor;

		// Texture holds the color to be used for all three components
		int index = int(v_texIndex);
		vec4 textureColor = texture(uTextures[index], vertexTextureCoordinate * uvScale);

        // Calculate Phong result
		vec3 phong = (ambient + diffuse + specular) * textureColor.xyz;
		vec3 secPhong = (ambient + secLightDiffuse + secLightSpecular) * textureColor.xyz;

		// Sends texture to the GPU for rendering
		//fragmentColor = texture(uTextures[index], vertexTextureCoordinate * uvScale);  // Sends texture to the GPU for rendering
		fragmentColor = vec4(phong + secPhong, 1.0); // Send lighting results to GPU
	}
);


// Primary Lamp shader source code
const GLchar* lampVertexShaderSource = GLSL(440,

	layout(location = 0) in vec3 position; // VAP position 0 for vertex position data

	// Uniform / Global variables for the transform matrices
    uniform mat4 model;
    uniform mat4 view;
    uniform mat4 projection;

    void main()
    {
    	gl_Position = projection * view * model * vec4(position, 1.0f);  // Tranforms vertices into clip coordinates
    }
);


// Fragment Shader Source Code
const GLchar* lampFragmentShaderSource = GLSL(440,

	out vec4 fragmentColor;  // For outgoing lamp color (pyramid) to the GPU

    void main()
    {
    	fragmentColor = vec4(1.0f);  // Set color to white (1.0f, 1.0f, 1.0f) with alpha 1.0
    }
);


// Secondary light Shader Source Code
const GLchar* secLightVertexShaderSource = GLSL(440,
	layout(location = 0) in vec3 position;  // VAP position 0 for vertex position data

    // Uniform / Global variables for the transform matrices
    uniform mat4 model;
    uniform mat4 view;
    uniform mat4 projection;

	void main()
	{
		gl_Position = projection * view * model * vec4(position, 1.0f);  // Tranforms vertices into clip coordinates
	}

);


// Fragment Shader Source Code
const GLchar* secLightFragmentShaderSource = GLSL(440,

	out vec4 fragmentColor;  // For outgoing fill color to the GPU

    void main()
    {
		fragmentColor = vec4(1.0f);  // Set color to white (1.0f, 1.0f, 1.0f) with alpha 1.0
	}
);


// Images are loaded with Y axis going down, but OpenGL's goes up, so flipping. . .
void flipImageVertically(unsigned char* image, int width, int height, int channels)
{
	for (int j = 0; j < height / 2; ++j)
	{
		int index1 = j * width * channels;
		int index2 = (height - 1 - j) * width * channels;

		for (int i = width * channels; i > 0; --i)
		{
			unsigned char tmp = image[index1];
			image[index1] = image[index2];
			image[index2] = tmp;
			++index1;
			++index2;
		}
	}
}



int main(int argc, char* argv[])
{
	if (!UInitialize(argc, argv, &gWindow))
		return EXIT_FAILURE;

	// Create the meshes
	UCreateMeshF(floorMesh); // Calls the function to creat the floor VBO
	UCreateMesh(feetMesh); // Calls the function to create the front bench foot VBO
	UCreateMeshB(backfootMesh);  // Calls the function to create the back foot VBO
	UCreateMesh2(legsMesh); // Calls the function to create the front bench leg VBO
	UCreateMesh2B(backlegMesh);  // Calls the function to create the back bench leg VBO
	UCreateMesh3(buttpadMesh); // Calls the function to create the bench buttpad VBO
	UCreateMesh4(backpadMesh); // Calls the function to create the back pad VBO
	UCreateMesh5(sphereMesh); // Calls the function to create the exercise ball VBO
	// Create the shader program
	if (!UCreateShaderProgram(vertexShaderSource, fragmentShaderSource, gProgramId))
		return EXIT_FAILURE;

	if (!UCreateShaderProgram(lampVertexShaderSource, lampFragmentShaderSource, gLampProgramId))
		return EXIT_FAILURE;

	if (!UCreateShaderProgram(secLightVertexShaderSource, secLightFragmentShaderSource, gSecLightProgramId))
		return EXIT_FAILURE;

	
	// Load texture
	const char * texFilename = "images/woodfloor.jpg";
	if (!UCreateTexture(texFilename, gTextureId))
	{
		cout << "Failed to load texture " << texFilename << endl;
		return EXIT_FAILURE;
	}
	
	// tell OpenGL for each sampler to which texture unit it belongs (only done once)
	glUseProgram(gProgramId);
	auto loc = glGetUniformLocation(gProgramId, "uTextures");
	int samplers[3] = { 0, 1, 2 };
	glUniform1iv(loc, 3, samplers);


	// Sets the background color of the window to black
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

	// render loop
	// -----------
	while (!glfwWindowShouldClose(gWindow))
	{
        // per-frame timing
		float currentFrame = glfwGetTime();
		gDeltaTime = currentFrame - gLastFrame;
		gLastFrame = currentFrame;


		// input
		// -----
		UProcessInput(gWindow);
		

		// Render this frame
		URender();


		glfwPollEvents();
	}


	// Release mesh data
	UDestroyMeshF(floorMesh);
	UDestroyMesh(feetMesh);
	UDestroyMesh(backfootMesh);
	UDestroyMesh2(legsMesh);
	UDestroyMesh2B(backlegMesh);
	UDestroyMesh3(buttpadMesh);
	UDestroyMesh4(backpadMesh);
	UDestroyMesh5(sphereMesh);
	

	// Release texture
	UDestroyTexture(gTextureId);
	UDestroyTexture(gTextureId1);
	UDestroyTexture(gTextureId2);


	// Release shader program
	UDestroyShaderProgram(gProgramId);
	UDestroyShaderProgram(gLampProgramId);
	UDestroyShaderProgram(gSecLightProgramId);


	exit(EXIT_SUCCESS); // Terminates the program successfully
}

// Initialize GLFW, GLEW, and create a window
bool UInitialize(int argc, char* argv[], GLFWwindow** window)
{
	// glfw: initialize and configure
	// ------------------------------
	glfwInit();
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

	// glfw window creation
	// --------------------
	*window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE, NULL, NULL);
	if (*window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return false;
	}
	glfwMakeContextCurrent(*window);
	glfwSetFramebufferSizeCallback(*window, UResizeWindow);
	glfwSetCursorPosCallback(*window, UMousePositionCallback);
	glfwSetScrollCallback(*window, UMouseScrollCallback);
	glfwSetMouseButtonCallback(*window, UMouseButtonCallback);

	
	// tell GLFW to capture our mouse
	glfwSetInputMode(*window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);


	// GLEW: initialize
	// ----------------
	// Note: if using GLEW version 1.13 or earlier
	glewExperimental = GL_TRUE;
	GLenum GlewInitResult = glewInit();

	if (GLEW_OK != GlewInitResult)
	{
		std::cerr << glewGetErrorString(GlewInitResult) << std::endl;
		return false;
	}

	// Displays GPU OpenGL version
	cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << endl;


	return true;
}


// glfw: whenever the window size changed (by OS or user resize) this callback function executes
void UResizeWindow(GLFWwindow* window, int width, int height)
{
	glViewport(0, 0, width, height);

	UpdateProjection();

}


// process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
void UProcessInput(GLFWwindow* window)
{
	static const float cameraSpeed = 2.5f;
	
    
	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
		glfwSetWindowShouldClose(window, true);

	float cameraOffset = cameraSpeed * gDeltaTime;

	if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
		gCamera.ProcessKeyboard(FORWARD, gDeltaTime);
	if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
		gCamera.ProcessKeyboard(BACKWARD, gDeltaTime);
	if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
		gCamera.ProcessKeyboard(LEFT, gDeltaTime);
	if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
		gCamera.ProcessKeyboard(RIGHT, gDeltaTime);
	if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
		gCamera.ProcessKeyboard(UPWARDS, gDeltaTime);
	if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
		gCamera.ProcessKeyboard(DOWNWARDS, gDeltaTime);

    // Change projection view (ortho or perspective)
	if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS)
		UpdateProjection(GL_TRUE);
}


// glfw: whenever the mouse moves, this callback is called
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos)
{
	if (gFirstMouse)
	{
		gLastX = xpos;
		gLastY = ypos;
		gFirstMouse = false;
	}


	float xoffset = xpos - gLastX;
	float yoffset = gLastY - ypos;  // reversed since y-coordinates go from bottom to top


	gLastX = xpos;
	gLastY = ypos;


	gCamera.ProcessMouseMovement(xoffset, yoffset);
}


// glfw: whenever the mouse scroll wheel scrolls, this callback is called
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset)
{
	gCamera.ProcessMouseScroll(yoffset);
}


// glfw: handle mouse button events
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods)
{
	switch (button)
	{
	case GLFW_MOUSE_BUTTON_LEFT:
	{
		if (action == GLFW_PRESS)
			cout << "Left mouse button pressed" << endl;
		else
			cout << "Left mouse button released" << endl;
	}
	break;


	case GLFW_MOUSE_BUTTON_MIDDLE:
	{
		if (action == GLFW_PRESS)
			cout << "Middle mouse button pressed" << endl;
		else
			cout << "Middle mouse button released" << endl;
	}
	break;


	case GLFW_MOUSE_BUTTON_RIGHT:
	{
		if (action == GLFW_PRESS)
			cout << "Right mouse button pressed" << endl;
		else
			cout << "Right mouse button released" << endl;
	}
	break;


	default:
		cout << "Unhandled mouse button event" << endl;
		break;
	}
}

// Function called to render a frame
void URender()
{
	// Enable z-depth
	glEnable(GL_DEPTH_TEST);

	// Clear the frame and z buffers
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	
	// Scale the object by 1 (original size)
	glm::mat4 scale = glm::scale(glm::vec3(1.0f, 1.0f, 1.0f));
	// Rotate shape counterclockwise by 45 degrees on the y axis
	glm::mat4 rotation = glm::rotate(-45.0f, glm::vec3(0.0f, 1.0f, 0.0f));
	// Place shapes at the origin
	glm::mat4 translation = glm::translate(glm::vec3(0.0f, -0.5f, 0.0f));


	// Model matrix: transformations are applied right-to-left order
	glm::mat4 model = translation * rotation * scale;
	

	// camera/view transformation 
	glm::mat4 view = gCamera.GetViewMatrix();


	// Creates a perspective projection
	glm::mat4 projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);

	// Set the shader to be used
	glUseProgram(gProgramId);


	// Retrieves and passes transform matrices to the Shader program
	GLint modelLoc = glGetUniformLocation(gProgramId, "model");
	GLint viewLoc = glGetUniformLocation(gProgramId, "view");
	GLint projLoc = glGetUniformLocation(gProgramId, "projection");


	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
	glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
	glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));


	// Reference matrix uniforms from the shader program for the pyramid color, light color, light position, and camera position
	GLint objectColorLoc = glGetUniformLocation(gProgramId, "objectColor");
	GLint lightColorLoc = glGetUniformLocation(gProgramId, "lightColor");
	GLint lightPositionLoc = glGetUniformLocation(gProgramId, "lightPos");
	GLint secLightColorLoc = glGetUniformLocation(gProgramId, "secLightColor");
	GLint secLightPositionLoc = glGetUniformLocation(gProgramId, "secLightPos");
	GLint viewPositionLoc = glGetUniformLocation(gProgramId, "viewPosition");


	// Pass color, light, and camera data to the Shader program's corresponding uniforms
	glUniform3f(objectColorLoc, gObjectColor.r, gObjectColor.g, gObjectColor.b);
	glUniform3f(lightColorLoc, gLightColor.r, gLightColor.g, gLightColor.b);
	glUniform3f(lightPositionLoc, gLightPosition.x, gLightPosition.y, gLightPosition.z);
	glUniform3f(secLightColorLoc, gSecLightColor.x, gSecLightColor.g, gSecLightColor.b);
	glUniform3f(secLightPositionLoc, gSecLightPosition.x, gSecLightPosition.y, gSecLightPosition.z);
	const glm::vec3 cameraPosition = gCamera.Position;
	glUniform3f(viewPositionLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z);


	GLint UVScaleLoc = glGetUniformLocation(gProgramId, "uvScale");
	glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));


	// Activate the VBOs contained within the mesh's feet VAO 
	// starting with floor
	glBindTextureUnit(0, floorTex);
	glBindVertexArray(floorMesh.vao);
	//bind textures on corresponding texture units
	glBindTexture(GL_TEXTURE_2D, gTextureId);
	glDrawArrays(GL_TRIANGLES, 0, floorMesh.nVertices);
	

	// then bench feet (front)
	glBindTextureUnit(1, feetTex);
	glBindVertexArray(feetMesh.vao);
	//bind textures on corresponding texture units
	glBindTexture(GL_TEXTURE_2D, gTextureId1);
	glDrawArrays(GL_TRIANGLES, 0, feetMesh.nVertices);

	
	// bench feet (back)
	glBindVertexArray(backfootMesh.vao);
	//bind textures on corresponding texture units
	glBindTexture(GL_TEXTURE_2D, gTextureId1);
	glDrawArrays(GL_TRIANGLES, 0, backfootMesh.nVertices);
	
	
	// bench legs (front) 
	glBindTextureUnit(1, feetTex);
	glBindVertexArray(legsMesh.vao);
	glBindTexture(GL_TEXTURE_2D, gTextureId1);
	glDrawArrays(GL_TRIANGLES, 0, legsMesh.nVertices);


	// bench legs (back)
	glBindVertexArray(backlegMesh.vao);
    glBindTexture(GL_TEXTURE_2D, gTextureId1);
	glDrawArrays(GL_TRIANGLES, 0, backlegMesh.nVertices);
	
	
	// then one short pyramid (buttpad)
	glBindTextureUnit(2, padTex);
	glBindVertexArray(buttpadMesh.vao);
	glBindTexture(GL_TEXTURE_2D, gTextureId2);
	glDrawArrays(GL_TRIANGLES, 0, buttpadMesh.nVertices);

	
	// one long pyramid (backpad)
	glBindVertexArray(backpadMesh.vao);
	glDrawArrays(GL_TRIANGLES, 0, backpadMesh.nVertices);

	
	// Exercise ball
	glBindTextureUnit(2, padTex);
	glBindVertexArray(sphereMesh.vao);
	glBindTexture(GL_TEXTURE_2D, gTextureId2);
	glDrawElements(GL_TRIANGLES, sphereMesh.nIndices, GL_UNSIGNED_INT, (void*)0);
	

	// Primary light: draw light
	glUseProgram(gLampProgramId);


	// Transform the shape used as a visual queue for the light source
	model = glm::translate(gLightPosition) * glm::scale(gLightScale);


	// Reference matrix uniforms from the Lamp Shader program
	modelLoc = glGetUniformLocation(gLampProgramId, "model");
	viewLoc = glGetUniformLocation(gLampProgramId, "view");
	projLoc = glGetUniformLocation(gLampProgramId, "projection");


	// Pass matrix data to the Primary Lamp Shader program's matrix uniforms
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
	glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
	glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));


	glDrawElements(GL_TRIANGLES, sphereMesh.nIndices, GL_UNSIGNED_INT, (void*)0);


	// Secondary light: draw light
	glUseProgram(gSecLightProgramId);


	// Transform the shape used as a visual queue for the fill source
	model = glm::translate(gSecLightPosition) * glm::scale(gSecLightScale);


	// Reference matrix uniforms from the Secondary Light shader program
	modelLoc = glGetUniformLocation(gSecLightProgramId, "model");
	viewLoc = glGetUniformLocation(gSecLightProgramId, "view");
	projLoc = glGetUniformLocation(gSecLightProgramId, "projection");


	// Pass matrix data to the Secondary Light Shader program's matrix uniforms
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
	glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
	glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));


	glDrawElements(GL_TRIANGLES, sphereMesh.nIndices, GL_UNSIGNED_INT, (void*)0);
	
	// Deactivate the Vertex Array Objects
	glBindVertexArray(0);
	glUseProgram(0);


	// glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
	glfwSwapBuffers(gWindow);  // Flips the back buffer with the front buffer every frame.
}



// Implements the UCreateMesh function for the floor plane object
// Transfer the location of the vertices of the following triangles to the GPU
bool UCreateMeshF(GLMesh& floorMesh)
{
	GLfloat verts[] = {
		// Triangle 1         Normals            Texture coords  index pos
		-3.0f, 0.0f,  3.0f,   0.0f, 1.0f, 0.0f,  0.0f, 0.0f,     0.0f,  // V0 
		-3.0f, 0.0f, -3.0f,   0.0f, 1.0f, 0.0f,  0.0f, 1.0f,     0.0f,  // V1
		 3.0f, 0.0f,  3.0f,   0.0f, 1.0f, 0.0f,  1.0f, 0.0f,     0.0f,  // V2
		// Triangle 2
		-3.0f, 0.0f, -3.0f,   0.0f, 1.0f, 0.0f,  0.0f, 1.0f,     0.0f,  // V1
		 3.0f, 0.0f,  3.0f,   0.0f, 1.0f, 0.0f,  1.0f, 0.0f,     0.0f,  // V2
		 3.0f, 0.0f, -3.0f,   0.0f, 1.0f, 0.0f,  1.0f, 1.0f,     0.0f   // V3
	};

	
	const GLuint floatsPerVertex = 3;
	const GLuint floatsPerNorm = 3;
	const GLuint floatsPerUV = 2;
	const GLuint floatsPerTex = 1;


	floorMesh.nVertices = sizeof(verts) / (sizeof(verts[0]) * (floatsPerVertex + floatsPerNorm + floatsPerUV));


	glGenVertexArrays(1, &floorMesh.vao); // bind to feet VAO
	glBindVertexArray(floorMesh.vao);  // mesh of one object bound to feet VAO


	// Create VBO for the vertex data
	glGenBuffers(1, &floorMesh.vbo);
	glBindBuffer(GL_ARRAY_BUFFER, floorMesh.vbo); // Activates the buffer
	glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU


	// Strides between vertex coordinates is 9 (x, y, z, n, n, n, s, t, i). 
	GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNorm + floatsPerUV + floatsPerTex); // The number of floats before each
	

	//Create Vertex Attribute Pointers
	glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
	glEnableVertexAttribArray(0);

	glVertexAttribPointer(1, floatsPerNorm, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
	glEnableVertexAttribArray(1);

	glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNorm)));
	glEnableVertexAttribArray(2);

	glVertexAttribPointer(3, floatsPerTex, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNorm + floatsPerUV)));
    

	const char * floorTex = "images/woodfloor.jpg";
	if (!UCreateTexture(floorTex, gTextureId))
	{
		cout << "Failed to load texture " << floorTex << endl;
		return EXIT_FAILURE;
	}
}


void UDestroyMeshF(GLMesh &floorMesh)
{
	glDeleteVertexArrays(1, &floorMesh.vao);
	glDeleteBuffers(1, &floorMesh.vbo);
}



// Implements the UCreateMesh function for Bench Feet object(s)
// Transfer the location of the vertices of the following triangles to the GPU
bool UCreateMesh(GLMesh& feetMesh)
{
	
	GLfloat verts[] = {
		// Bench foot 
		//----------------------------------------------------------
		// vertex positions      Normals             textures(s,t)  Tex index
		// Front side
		// ----------
		//Triangle 1           
		 0.0f,  0.05f,  0.5f,    0.0f, 0.0f, 1.0f,   1.0f, 1.0f,    1.0f,  // V0
		-0.5f,  0.05f,  0.5f,    0.0f, 0.0f, 1.0f,   0.0f, 1.0f,    1.0f,  // V1 
		 0.0f,  0.0f,   0.5f,    0.0f, 0.0f, 1.0f,   1.0f, 0.0f,    1.0f,  // V3 
		//Triangle 2
		-0.5f,  0.05f,  0.5f,    0.0f, 0.0f, 1.0f,   0.0f, 1.0f,    1.0f,  // V1 
		-0.5f,  0.0f,   0.5f,    0.0f, 0.0f, 1.0f,   0.0f, 0.0f,    1.0f,  // V2 
		 0.0f,  0.0f,   0.5f,    0.0f, 0.0f, 1.0f,   1.0f, 0.0f,    1.0f,  // V3 
		// Back side
		// ---------
		//Triangle 3
		 0.0f,  0.05f, 0.35f,    0.0f, 0.0f, -1.0f,  0.0f, 1.0f,    1.0f,  // V4 
		-0.5f,  0.05f, 0.35f,    0.0f, 0.0f, -1.0f,  1.0f, 1.0f,    1.0f,  // V5 
		-0.5f,  0.0f,  0.35f,    0.0f, 0.0f, -1.0f,  1.0f, 0.0f,    1.0f,  // V6 
		//Triangle 4
		 0.0f,  0.05f, 0.35f,    0.0f, 0.0f, -1.0f,  0.0f, 1.0f,    1.0f,  // V4 
		-0.5f,  0.0f,  0.35f,    0.0f, 0.0f, -1.0f,  1.0f, 0.0f,    1.0f,  // V6 
		 0.0f,  0.0f,  0.35f,    0.0f, 0.0f, -1.0f,  0.0f, 0.0f,    1.0f,  // V7 
		 // Left side
		 // ---------
		//Triangle 5
		-0.5f,  0.05f,  0.5f,    -1.0f, 0.0f, 0.0f,  1.0f, 1.0f,    1.0f,  // V1 
		-0.5f,  0.0f,   0.5f,    -1.0f, 0.0f, 0.0f,  1.0f, 0.0f,    1.0f,  // V2 
		-0.5f,  0.05f, 0.35f,    -1.0f, 0.0f, 0.0f,  0.0f, 1.0f,    1.0f,  // V5 
		//Triangle 6
		-0.5f,  0.0f,   0.5f,    -1.0f, 0.0f, 0.0f,  1.0f, 0.0f,    1.0f,  // V2
		-0.5f,  0.05f, 0.35f,    -1.0f, 0.0f, 0.0f,  0.0f, 1.0f,    1.0f,  // V5 
		-0.5f,  0.0f,  0.35f,    -1.0f, 0.0f, 0.0f,  0.0f, 0.0f,    1.0f,  // V6
		// Right side
		// ----------
		// Triangle 7
		 0.0f,  0.05f,  0.5f,    1.0f, 0.0f, 0.0f,   0.0f, 1.0f,    1.0f,  // V0 
		 0.0f,  0.0f,   0.5f,    1.0f, 0.0f, 0.0f,   0.0f, 0.0f,    1.0f,  // V3 
		 0.0f,  0.05f, 0.35f,    1.0f, 0.0f, 0.0f,   1.0f, 1.0f,    1.0f,  // V4 
		// Triangle 8
		 0.0f,  0.0f,   0.5f,    1.0f, 0.0f, 0.0f,   0.0f, 0.0f,    1.0f,  // V3 
		 0.0f,  0.05f, 0.35f,    1.0f, 0.0f, 0.0f,   1.0f, 1.0f,    1.0f,  // V4 
		 0.0f,  0.0f,  0.35f,    1.0f, 0.0f, 0.0f,   1.0f, 0.0f,    1.0f,  // V7 
		// Top side
		// ---------
		// Triangle 9
		 0.0f,  0.05f,  0.5f,    0.0f, 1.0f, 0.0f,   1.0f, 0.0f,    1.0f,  // V0 
		 0.0f,  0.05f, 0.35f,    0.0f, 1.0f, 0.0f,   1.0f, 1.0f,    1.0f,  // V4 
		-0.5f,  0.05f, 0.35f,    0.0f, 1.0f, 0.0f,   0.0f, 1.0f,    1.0f,  // V5 
		// Triangle 10
		 0.0f,  0.05f,  0.5f,    0.0f, 1.0f, 0.0f,   1.0f, 0.0f,    1.0f,  // V0 
		-0.5f,  0.05f,  0.5f,    0.0f, 1.0f, 0.0f,   0.0f, 0.0f,    1.0f,  // V1 
		-0.5f,  0.05f, 0.35f,    0.0f, 1.0f, 0.0f,   0.0f, 1.0f,    1.0f,  // V5 
		// Bottom side
		// -----------
		// Triangle 11
		-0.5f,  0.0f,   0.5f,    0.0f, -1.0f, 0.0f,  0.0f, 1.0f,    1.0f,  // V2 
		 0.0f,  0.0f,   0.5f,    0.0f, -1.0f, 0.0f,  1.0f, 1.0f,    1.0f,  // V3 
		 0.0f,  0.0f,  0.35f,    0.0f, -1.0f, 0.0f,  1.0f, 0.0f,    1.0f,  // V7 
		// Triangle 12
		-0.5f,  0.0f,   0.5f,    0.0f, -1.0f, 0.0f,  0.0f, 1.0f,    1.0f,  // V2 
		-0.5f,  0.0f,  0.35f,    0.0f, -1.0f, 0.0f,  0.0f, 0.0f,    1.0f,  // V6 
		 0.0f,  0.0f,  0.35f,    0.0f, -1.0f, 0.0f,  1.0f, 0.0f,    1.0f  // V7 
	};


	const GLuint floatsPerVertex = 3;
	const GLuint floatsPerNorm = 3;
	const GLuint floatsPerUV = 2;
	const GLuint floatsPerTex = 1;


	feetMesh.nVertices = sizeof(verts) / (sizeof(verts[0]) * (floatsPerVertex + floatsPerNorm + floatsPerUV + floatsPerTex));


	glGenVertexArrays(1, &feetMesh.vao); // bind to feet VAO
	glBindVertexArray(feetMesh.vao);  // mesh of one object bound to feet VAO


	// Create buffer for the vertex data
	glGenBuffers(1, &feetMesh.vbo);
	glBindBuffer(GL_ARRAY_BUFFER, feetMesh.vbo); // Activates the buffer
	glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU


	// Strides between vertex coordinates is 9 (x, y, z, n, n, n, s, t, i). 
	GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNorm + floatsPerUV + floatsPerTex); // The number of floats before each


	//Create Vertex Attribute Pointers
	glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
	glEnableVertexAttribArray(0);

	glVertexAttribPointer(1, floatsPerNorm, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
	glEnableVertexAttribArray(1);

	glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex + floatsPerNorm));
	glEnableVertexAttribArray(2);

	glVertexAttribPointer(3, floatsPerTex, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNorm + floatsPerUV)));
	//glEnableVertexAttribArray(3);


	const char * feetTex = "images/metal.jpg";
	if (!UCreateTexture(feetTex, gTextureId1))
	{
		cout << "Failed to load texture " << feetTex << endl;
		return EXIT_FAILURE;
	}
}


void UDestroyMesh(GLMesh &feetMesh)
{
	glDeleteVertexArrays(1, &feetMesh.vao);
	glDeleteBuffers(1, &feetMesh.vbo);
}


bool UCreateMeshB(GLMesh& backfootMesh)
{

	GLfloat verts[] = {
		// Bench foot 
		//----------------------------------------------------------
		// vertex positions      Normals             texture(s,t) //texture index
		// Front side
		// ----------
		//Triangle 1
		 0.0f,  0.05f,  -0.5f,   0.0f, 0.0f, 1.0f,   1.0f, 1.0f,    1.0f,  // V0
		-0.5f,  0.05f,  -0.5f,   0.0f, 0.0f, 1.0f,   0.0f, 1.0f,    1.0f,  // V1
		 0.0f,  0.0f,   -0.5f,   0.0f, 0.0f, 1.0f,   1.0f, 0.0f,    1.0f,  // V3
		//Triangle 2
		-0.5f,  0.05f,  -0.5f,   0.0f, 0.0f, 1.0f,   0.0f, 1.0f,    1.0f,  // V1
		-0.5f,  0.0f,   -0.5f,   0.0f, 0.0f, 1.0f,   0.0f, 0.0f,    1.0f,  // V2
		 0.0f,  0.0f,   -0.5f,   0.0f, 0.0f, 1.0f,   1.0f, 0.0f,    1.0f,  // V3
		// Back side
		// ---------
		//Triangle 3
		 0.0f,  0.05f, -0.35f,   0.0f, 0.0f, -1.0f,  0.0f, 1.0f,    1.0f,  // V4
		-0.5f,  0.05f, -0.35f,   0.0f, 0.0f, -1.0f,  1.0f, 1.0f,    1.0f,  // V5
		-0.5f,  0.0f,  -0.35f,   0.0f, 0.0f, -1.0f,  1.0f, 0.0f,    1.0f,  // V6
		//Triangle 4
		 0.0f,  0.05f, -0.35f,   0.0f, 0.0f, -1.0f,  0.0f, 1.0f,    1.0f,  // V4
		-0.5f,  0.0f,  -0.35f,   0.0f, 0.0f, -1.0f,  1.0f, 0.0f,    1.0f,  // V6
		 0.0f,  0.0f,  -0.35f,   0.0f, 0.0f, -1.0f,  0.0f, 0.0f,    1.0f,  // V7
		 // Left side
		 // ---------
		//Triangle 5
		-0.5f,  0.05f,  -0.5f,   -1.0f, 0.0f, 0.0f,  1.0f, 1.0f,    1.0f,  // V1
		-0.5f,  0.0f,   -0.5f,   -1.0f, 0.0f, 0.0f,  1.0f, 0.0f,    1.0f,  // V2
		-0.5f,  0.05f,  -0.35f,  -1.0f, 0.0f, 0.0f,  0.0f, 1.0f,    1.0f,  // V5
		//Triangle 6
		-0.5f,  0.0f,   -0.5f,   -1.0f, 0.0f, 0.0f,  1.0f, 0.0f,    1.0f,  // V2
		-0.5f,  0.05f,  -0.35f,  -1.0f, 0.0f, 0.0f,  0.0f, 1.0f,    1.0f,  // V5
		-0.5f,  0.0f,   -0.35f,  -1.0f, 0.0f, 0.0f,  0.0f, 0.0f,    1.0f,  // V6
		// Right side
		// ----------
		// Triangle 7
		 0.0f,  0.05f,  -0.5f,   1.0f, 0.0f, 0.0f,   0.0f, 1.0f,    1.0f,  // V0
		 0.0f,  0.0f,   -0.5f,   1.0f, 0.0f, 0.0f,   0.0f, 0.0f,    1.0f,  // V3 
		 0.0f,  0.05f,  -0.35f,  1.0f, 0.0f, 0.0f,   1.0f, 1.0f,    1.0f,  // V4
		// Triangle 8
		 0.0f,  0.0f,   -0.5f,   1.0f, 0.0f, 0.0f,   0.0f, 0.0f,    1.0f,  // V3
		 0.0f,  0.05f,  -0.35f,  1.0f, 0.0f, 0.0f,   1.0f, 1.0f,    1.0f,  // V4
		 0.0f,  0.0f,   -0.35f,  1.0f, 0.0f, 0.0f,   1.0f, 0.0f,    1.0f,  // V7 
		// Top side
		// ---------
		// Triangle 9
		 0.0f,  0.05f,  -0.5f,   0.0f, 1.0f, 0.0f,   1.0f, 0.0f,    1.0f,  // V0 
		 0.0f,  0.05f,  -0.35f,  0.0f, 1.0f, 0.0f,   1.0f, 1.0f,    1.0f,  // V4
		-0.5f,  0.05f,  -0.35f,  0.0f, 1.0f, 0.0f,   0.0f, 1.0f,    1.0f,  // V5
		// Triangle 10
		 0.0f,  0.05f,  -0.5f,   0.0f, 1.0f, 0.0f,   1.0f, 0.0f,    1.0f,  // V0
		-0.5f,  0.05f,  -0.5f,   0.0f, 1.0f, 0.0f,   0.0f, 0.0f,    1.0f,  // V1
		-0.5f,  0.05f,  -0.35f,  0.0f, 1.0f, 0.0f,   0.0f, 1.0f,    1.0f,  // V5 
		// Bottom side
		// -----------
		// Triangle 11
		-0.5f,  0.0f,   -0.5f,   0.0f, -1.0f, 0.0f,  0.0f, 1.0f,    1.0f,  // V2
		 0.0f,  0.0f,   -0.5f,   0.0f, -1.0f, 0.0f,  1.0f, 1.0f,    1.0f,  // V3
		 0.0f,  0.0f,   -0.35f,  0.0f, -1.0f, 0.0f,  1.0f, 0.0f,    1.0f,  // V7
		// Triangle 12
		-0.5f,  0.0f,   -0.5f,   0.0f, -1.0f, 0.0f,  0.0f, 1.0f,    1.0f,  // V2
		-0.5f,  0.0f,   -0.35f,  0.0f, -1.0f, 0.0f,  0.0f, 0.0f,    1.0f,  // V6
		 0.0f,  0.0f,   -0.35f,  0.0f, -1.0f, 0.0f,  1.0f, 0.0f,    1.0f   // V7 
	};


	const GLuint floatsPerVertex = 3;
	const GLuint floatsPerNorm = 3;
	const GLuint floatsPerUV = 2;
	const GLuint floatsPerTex = 1;


	backfootMesh.nVertices = sizeof(verts) / (sizeof(verts[0]) * (floatsPerVertex + floatsPerNorm + floatsPerUV + floatsPerTex));


	glGenVertexArrays(1, &backfootMesh.vao); // bind to feet VAO
	glBindVertexArray(backfootMesh.vao);  // mesh of one object bound to feet VAO


	// Create buffer for the vertices
	glGenBuffers(1, &backfootMesh.vbo);
	glBindBuffer(GL_ARRAY_BUFFER, backfootMesh.vbo); // Activates the buffer
	glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU


	// Strides between vertex coordinates is 9 (x, y, z, n, n, n, s, t, i). 
	GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNorm + floatsPerUV + floatsPerTex); // The number of floats before each


	//Create Vertex Attribute Pointers
	glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
	glEnableVertexAttribArray(0);


	glVertexAttribPointer(1, floatsPerNorm, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
	glEnableVertexAttribArray(1);

	glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNorm)));
	glEnableVertexAttribArray(2);


	glVertexAttribPointer(3, floatsPerTex, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNorm + floatsPerUV)));
	//glEnableVertexAttribArray(3);


	const char * feetTex = "images/metal.jpg";
	if (!UCreateTexture(feetTex, gTextureId))
	{
		cout << "Failed to load texture " << feetTex << endl;
		return EXIT_FAILURE;
	}
}


void UDestroyMeshB(GLMesh& backfootMesh)
{
	glDeleteVertexArrays(1, &backfootMesh.vao);
	glDeleteBuffers(1, &backfootMesh.vbo);
}


// -----------------------------------------------------------
// Implements the UCreateMesh2 function for Bench Leg object(s)
bool UCreateMesh2(GLMesh& legsMesh)
{

	GLfloat verts[] = {
		// Front bench leg 
		//----------------------------------------------------------
		// vertex positions      Normals             textures (s, t)     tex index
		// Front side
		// ----------
		//Triangle 1
		-0.175f, 0.35f,  0.5f,   0.0f, 0.0f, 1.0f,   1.0f, 1.0f,         1.0f, // V0 
		-0.325f, 0.35f,  0.5f,   0.0f, 0.0f, 1.0f,   0.0f, 1.0f,         1.0f, // V1 
		-0.175f, 0.05f,  0.5f,   0.0f, 0.0f, 1.0f,   1.0f, 0.0f,         1.0f, // V3 
		//Triangle 2
		-0.325f,  0.35f,  0.5f,  0.0f, 0.0f, 1.0f,   0.0f, 1.0f,         1.0f, // V1 
		-0.325f,  0.05f,  0.5f,  0.0f, 0.0f, 1.0f,   0.0f, 0.0f,         1.0f, // V2 
		-0.175f, 0.05f,  0.5f,   0.0f, 0.0f, 1.0f,   1.0f, 0.0f,         1.0f, // V3 
		// Back side
		// ---------
		//Triangle 3
		-0.175f, 0.35f,  0.35f,  0.0f, 0.0f, -1.0f,  0.0f, 1.0f,         1.0f, // V4 
		-0.325f,  0.35f,  0.35f, 0.0f, 0.0f, -1.0f,  1.0f, 1.0f,         1.0f, // V5
		-0.325f,  0.05f,  0.35f, 0.0f, 0.0f, -1.0f,  0.0f, 0.0f,         1.0f, // V6 
		//Triangle 4
		-0.175f, 0.35f,  0.35f,  0.0f, 0.0f, -1.0f,  0.0f, 1.0f,         1.0f, // V4
		-0.325f,  0.05f,  0.35f, 0.0f, 0.0f, -1.0f,  0.0f, 0.0f,         1.0f, // V6 
		-0.175f, 0.05f,  0.35f,  0.0f, 0.0f, -1.0f,  1.0f, 0.0f,         1.0f, // V7 
		 // Left side
		 // ---------
		//Triangle 5
		-0.325f,  0.35f,  0.5f,  -1.0f, 0.0f, 0.0f,  1.0f, 1.0f,         1.0f, // V1 
		-0.325f,  0.05f,  0.5f,  -1.0f, 0.0f, 0.0f,  1.0f, 0.0f,         1.0f, // V2 
		-0.325f,  0.35f,  0.35f, -1.0f, 0.0f, 0.0f,  0.0f, 1.0f,         1.0f, // V5 
		//Triangle 6
		-0.325f,  0.05f,  0.5f,  -1.0f, 0.0f, 0.0f,  1.0f, 0.0f,         1.0f, // V2 
		-0.325f,  0.35f,  0.35f, -1.0f, 0.0f, 0.0f,  0.0f, 1.0f,         1.0f, // V5 
		-0.325f,  0.05f,  0.35f, -1.0f, 0.0f, 0.0f,  0.0f, 0.0f,         1.0f, // V7 
		// Right side
		// ----------
		// Triangle 7
		-0.175f, 0.35f,  0.5f,    1.0f, 0.0f, 0.0f,  0.0f, 1.0f,         1.0f, // V0 
		-0.175f, 0.05f,  0.5f,    1.0f, 0.0f, 0.0f,  0.0f, 0.0f,         1.0f, // V3 
		-0.175f, 0.35f,  0.35f,   1.0f, 0.0f, 0.0f,  1.0f, 1.0f,         1.0f, // V4 
		// Triangle 8
		-0.175f, 0.05f,  0.5f,    1.0f, 0.0f, 0.0f,  0.0f, 0.0f,         1.0f, // V3 
		-0.175f, 0.35f,  0.35f,   1.0f, 0.0f, 0.0f,  1.0f, 1.0f,         1.0f, // V4 
		-0.175f, 0.05f,  0.35f,   1.0f, 0.0f, 0.0f,  1.0f, 0.0f,         1.0f, // V6 
		// Top side
		// ---------
		// Triangle 9
		-0.175f, 0.35f,  0.5f,    0.0f, 1.0f, 0.0f,  1.0f, 0.0f,         1.0f, // V0 
		-0.175f, 0.35f,  0.35f,   0.0f, 1.0f, 0.0f,  1.0f, 1.0f,         1.0f, // V4 
		-0.325f,  0.35f,  0.35f,  0.0f, 1.0f, 0.0f,  0.0f, 1.0f,         1.0f, // V5 
		// Triangle 10
		-0.175f, 0.35f,  0.5f,    0.0f, 1.0f, 0.0f,  1.0f, 0.0f,         1.0f, // V0 
		-0.325f,  0.35f,  0.5f,   0.0f, 1.0f, 0.0f,  0.0f, 0.0f,         1.0f, // V1 
		-0.325f,  0.35f,  0.35f,  0.0f, 1.0f, 0.0f,  0.0f, 1.0f,         1.0f, // V5 
		// Bottom side
		// -----------
		// Triangle 11
		-0.325f,  0.05f,  0.5f,  0.0f, -1.0f, 0.0f,  0.0f, 1.0f,         1.0f, // V2 
		-0.175f, 0.05f,  0.5f,   0.0f, -1.0f, 0.0f,  1.0f, 1.0f,         1.0f, // V3 
		-0.175f, 0.05f,  0.35f,  0.0f, -1.0f, 0.0f,  1.0f, 0.0f,         1.0f, // V7 
		// Triangle 12
		-0.325f,  0.05f,  0.5f,  0.0f, -1.0f, 0.0f,  0.0f, 1.0f,         1.0f, // V2 
		-0.325f,  0.05f,  0.35f, 0.0f, -1.0f, 0.0f,  0.0f, 0.0f,         1.0f, // V6 
		-0.175f, 0.05f,  0.35f,  0.0f, -1.0f, 0.0f,  1.0f, 0.0f,         1.0f  // V7 
	};


	const GLuint floatsPerVertex = 3;
	const GLuint floatsPerNorm = 3;
	const GLuint floatsPerUV = 2;
	const GLuint floatsPerTex = 1;


	legsMesh.nVertices = sizeof(verts) / (sizeof(verts[0]) * (floatsPerVertex + floatsPerNorm + floatsPerUV + floatsPerTex));


	glGenVertexArrays(1, &legsMesh.vao); // generate legs VAO
	glBindVertexArray(legsMesh.vao);  // mesh of one object bound to legs VAO


	// Create VBO
	glGenBuffers(1, &legsMesh.vbo);
	glBindBuffer(GL_ARRAY_BUFFER, legsMesh.vbo); // Activates the buffer
	glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU


	// Strides between vertex coordinates is 9 (x, y, z, n, n, n, s, t, i). 
	GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNorm + floatsPerUV + floatsPerTex); // The number of floats before each


	//Create Vertex Attribute Pointers
	glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
	glEnableVertexAttribArray(0);


	glVertexAttribPointer(1, floatsPerNorm, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));


	glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNorm)));
	glEnableVertexAttribArray(2);


	glVertexAttribPointer(3, floatsPerTex, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNorm + floatsPerUV)));
    //glEnableVertexAttribArray(3);


	const char * feetTex = "images/metal.jpg";
	if (!UCreateTexture(feetTex, gTextureId))
	{
		cout << "Failed to load texture " << feetTex << endl;
		return EXIT_FAILURE;
	}
}


void UDestroyMesh2(GLMesh& legsMesh)
{
	glDeleteVertexArrays(1, &legsMesh.vao);
	glDeleteBuffers(1, &legsMesh.vbo);
}


// Back bench leg
bool UCreateMesh2B(GLMesh& backlegMesh)
{

	GLfloat verts[] = {
		// Back bench leg 
		//----------------------------------------------------------
		// vertex positions       Normals             textures (s, t)  texture index
		// Front side
		// ----------
		//Triangle 1
		-0.175f, 0.35f,  -0.5f,   0.0f, 0.0f, 1.0f,   1.0f, 1.0f,      1.0f,// V0
		-0.325f,  0.35f, -0.5f,   0.0f, 0.0f, 1.0f,   0.0f, 1.0f,      1.0f,// V1
		-0.175f, 0.05f,  -0.5f,   0.0f, 0.0f, 1.0f,   1.0f, 0.0f,      1.0f,// V3
		//Triangle 2
		-0.325f,  0.35f,  -0.5f,  0.0f, 0.0f, 1.0f,   0.0f, 1.0f,      1.0f,// V1 
		-0.325f,  0.05f,  -0.5f,  0.0f, 0.0f, 1.0f,   0.0f, 0.0f,      1.0f,// V2
		-0.175f, 0.05f,   -0.5f,  0.0f, 0.0f, 1.0f,   1.0f, 0.0f,      1.0f,// V3 
		// Back side
		// ---------
		//Triangle 3
		-0.175f, 0.35f,   -0.35f, 0.0f, 0.0f, -1.0f,  0.0f, 1.0f,      1.0f,// V4
		-0.325f,  0.35f,  -0.35f, 0.0f, 0.0f, -1.0f,  1.0f, 1.0f,      1.0f,// V5
		-0.325f,  0.05f,  -0.35f, 0.0f, 0.0f, -1.0f,  0.0f, 0.0f,      1.0f,// V6
		//Triangle 4
		-0.175f, 0.35f,   -0.35f, 0.0f, 0.0f, -1.0f,  0.0f, 1.0f,      1.0f,// V4
		-0.325f,  0.05f,  -0.35f, 0.0f, 0.0f, -1.0f,  0.0f, 0.0f,      1.0f,// V6
		-0.175f, 0.05f,   -0.35f, 0.0f, 0.0f, -1.0f,  1.0f, 0.0f,      1.0f,// V7 
		 // Left side
		 // ---------
		//Triangle 5
		-0.325f,  0.35f,  -0.5f,  -1.0f, 0.0f, 0.0f,  1.0f, 1.0f,      1.0f,// V1 
		-0.325f,  0.05f,  -0.5f,  -1.0f, 0.0f, 0.0f,  1.0f, 0.0f,      1.0f,// V2 
		-0.325f,  0.35f,  -0.35f, -1.0f, 0.0f, 0.0f,  0.0f, 1.0f,      1.0f,// V5
		//Triangle 6
		-0.325f,  0.05f,  -0.5f,  -1.0f, 0.0f, 0.0f,  1.0f, 0.0f,      1.0f,// V2
		-0.325f,  0.35f,  -0.35f, -1.0f, 0.0f, 0.0f,  0.0f, 1.0f,      1.0f,// V5
		-0.325f,  0.05f,  -0.35f, -1.0f, 0.0f, 0.0f,  0.0f, 0.0f,      1.0f,// V7
		// Right side
		// ----------
		// Triangle 7
		-0.175f,  0.35f,  -0.5f,  1.0f, 0.0f, 0.0f,   0.0f, 1.0f,      1.0f,// V0
		-0.175f,  0.05f,  -0.5f,  1.0f, 0.0f, 0.0f,   0.0f, 0.0f,      1.0f,// V3
		-0.175f, 0.35f,  -0.35f,  1.0f, 0.0f, 0.0f,   1.0f, 1.0f,      1.0f,// V4 
		// Triangle 8
		-0.175f, 0.05f,  -0.5f,   1.0f, 0.0f, 0.0f,   0.0f, 0.0f,      1.0f,// V3
		-0.175f, 0.35f,  -0.35f,  1.0f, 0.0f, 0.0f,   1.0f, 1.0f,      1.0f,// V4 
		-0.175f, 0.05f,  -0.35f,  1.0f, 0.0f, 0.0f,   1.0f, 0.0f,      1.0f,// V6
		// Top side
		// ---------
		// Triangle 9
		-0.175f, 0.35f,  -0.5f,   0.0f, 1.0f, 0.0f,   1.0f, 0.0f,      1.0f,// V0
		-0.175f, 0.35f,  -0.35f,  0.0f, 1.0f, 0.0f,   1.0f, 1.0f,      1.0f,// V4
		-0.325f,  0.35f,  -0.35f, 0.0f, 1.0f, 0.0f,   0.0f, 1.0f,      1.0f,// V5
		// Triangle 10
		-0.175f, 0.35f,   -0.5f,  0.0f, 1.0f, 0.0f,   1.0f, 0.0f,      1.0f,// V0 
		-0.325f,  0.35f,  -0.5f,  0.0f, 1.0f, 0.0f,   0.0f, 0.0f,      1.0f,// V1
		-0.325f,  0.35f,  -0.35f, 0.0f, 1.0f, 0.0f,   0.0f, 1.0f,      1.0f,// V5
		// Bottom side
		// -----------
		// Triangle 11
		-0.325f,  0.05f,  -0.5f,  0.0f, -1.0f, 0.0f,  0.0f, 1.0f,      1.0f,// V2
		-0.175f, 0.05f,   -0.5f,  0.0f, -1.0f, 0.0f,  1.0f, 1.0f,      1.0f,// V3
		-0.175f, 0.05f,   -0.35f, 0.0f, -1.0f, 0.0f,  1.0f, 0.0f,      1.0f,// V7
		// Triangle 12
		-0.325f,  0.05f,  -0.5f,  0.0f, -1.0f, 0.0f,  0.0f, 1.0f,      1.0f,// V2 
		-0.325f,  0.05f,  -0.35f, 0.0f, -1.0f, 0.0f,  0.0f, 0.0f,      1.0f,// V6 
		-0.175f, 0.05f,   -0.35f, 0.0f, -1.0f, 0.0f,  1.0f, 0.0f,      1.0f // V7
	};


	const GLuint floatsPerVertex = 3;
	const GLuint floatsPerNorm = 3;
	const GLuint floatsPerUV = 2;
	const GLuint floatsPerTex = 1;


	backlegMesh.nVertices = sizeof(verts) / (sizeof(verts[0]) * (floatsPerVertex + floatsPerNorm + floatsPerUV + floatsPerTex));


	glGenVertexArrays(1, &backlegMesh.vao); // generate legs VAO
	glBindVertexArray(backlegMesh.vao);  // mesh of one object bound to legs VAO


	// Create VBO
	glGenBuffers(1, &backlegMesh.vbo);
	glBindBuffer(GL_ARRAY_BUFFER, backlegMesh.vbo); // Activates the buffer
	glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU


	// Strides between vertex coordinates is 9 (x, y, z, n, n, n, s, t, i). 
	GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNorm + floatsPerUV + floatsPerTex); // The number of floats before each


	//Create Vertex Attribute Pointers
	glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
	glEnableVertexAttribArray(0);


	glVertexAttribPointer(1, floatsPerNorm, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
	glEnableVertexAttribArray(1);


	glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNorm)));
	glEnableVertexAttribArray(2);


	glVertexAttribPointer(3, floatsPerTex, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNorm + floatsPerUV)));
	//glEnableVertexAttribArray(3);


	const char * feetTex = "images/metal.jpg";
	if (!UCreateTexture(feetTex, gTextureId))
	{
		cout << "Failed to load texture " << feetTex << endl;
		return EXIT_FAILURE;
	}
}


void UDestroyMesh2B(GLMesh& backlegMesh)
{
	glDeleteVertexArrays(1, &backlegMesh.vao);
	glDeleteBuffers(1, &backlegMesh.vbo);
}


// Implements the UCreateMesh function for buttpad object
// Transfer the location of the vertices of the following triangles to the GPU
bool UCreateMesh3(GLMesh& buttpadMesh)
{

	GLfloat verts[] = {
		// vertex positions    Normals                  textures (s, t)     texture index
		//Triangle 1           (top face: positive y)
		-0.25f, 0.35f, 0.60f,  0.0f, 0.119f, 0.017f,   0.5f, 1.0f,         2.0f,  // V0 
		-0.08f, 0.4f,  0.25f,  0.0f, 0.119f, 0.017f,   0.0f, 0.0f,         2.0f,  // V1 
		-0.42f, 0.4f,  0.25f,  0.0f, 0.119f, 0.017f,   1.0f, 0.0f,         2.0f,  // V2 
		//Triangle 2           (left face: negative x, positive z)
		-0.25f, 0.35f, 0.60f,  -0.0175f, 0.0f, 0.0085f, 0.5f, 1.0f,         2.0f,  // V0 
		-0.42f, 0.4f,  0.25f,  -0.0175f, 0.0f, 0.0085f, 0.0f, 0.0f,         2.0f,  // V2 
		-0.42f, 0.35f, 0.25f,  -0.0175f, 0.0f, 0.0085f, 1.0f, 0.0f,         2.0f,  // V3 
		//Triangle 3           (bottom face: negative y)
		-0.25f, 0.35f, 0.60f,  -0.0175f, 0.0f, 0.0085f, 0.5f, 1.0f,         2.0f,  // V0 
		-0.42f, 0.35f, 0.25f,  -0.0175f, 0.0f, 0.0085f, 0.0f, 0.0f,         2.0f,  // V3 
		-0.08f, 0.35f, 0.25f,  -0.0175f, 0.0f, 0.0085f, 1.0f, 0.0f,         2.0f,  // V4 
		//Triangle 4           (right face: positive x, positive z)
		-0.25f, 0.35f, 0.60f,  0.0175f, 0.0f, 0.0085f,  0.5f, 1.0f,         2.0f,  // V0 
		-0.08f, 0.35f, 0.25f,  0.0175f, 0.0f, 0.0085f,  0.0f, 0.0f,         2.0f,  // V4 
		-0.08f, 0.4f,  0.25f,  0.0175f, 0.0f, 0.0085f,  1.0f, 0.0f,         2.0f,  // V1 
		//Triangle 5           (back base: top triangle, negative z)
		-0.08f, 0.4f,  0.25f,  0.0f, 0.0f, -0.017f,     1.0f, 1.0f,         2.0f,  // V1 
		-0.42f, 0.4f,  0.25f,  0.0f, 0.0f, -0.017f,     1.0f, 0.0f,         2.0f,  // V2 
		-0.08f, 0.35f, 0.25f,  0.0f, 0.0f, -0.017f,     0.0f, 1.0f,         2.0f,  // V4
		//Triangle 6           (back base: bottom triangle, negative z)
		-0.42f, 0.4f,  0.25f,  0.0f, 0.0f, -0.017f,     1.0f, 0.0f,         2.0f,  // V2 
		-0.42f, 0.35f, 0.25f,  0.0f, 0.0f, -0.017f,     0.0f, 0.0f,         2.0f,  // V3 
		-0.08f, 0.35f, 0.25f,  0.0f, 0.0f, -0.017f,     0.0f, 1.0f,         2.0f   // V4 

	};


	const GLuint floatsPerVertex = 3;
	const GLuint floatsPerNorm = 3;
	const GLuint floatsPerUV = 2;
	const GLuint floatsPerTex = 1;


	buttpadMesh.nVertices = sizeof(verts) / (sizeof(verts[0]) * (floatsPerVertex + floatsPerNorm + floatsPerUV + floatsPerTex));

	glGenVertexArrays(1, &buttpadMesh.vao); // bind to feet VAO
	glBindVertexArray(buttpadMesh.vao);  // mesh of one object bound to feet VAO


	// Create 2 buffers: first one for the vertex data; second one for the indices
	glGenBuffers(1, &buttpadMesh.vbo);
	glBindBuffer(GL_ARRAY_BUFFER, buttpadMesh.vbo); // Activates the buffer
	glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU


	// Strides between vertex coordinates is 9 (x, y, z, n, n, n, s, t, i). 
	GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNorm + floatsPerUV + floatsPerTex); // The number of floats before each


	//Create Vertex Attribute Pointers
	glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
	glEnableVertexAttribArray(0);

	glVertexAttribPointer(1, floatsPerNorm, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
	glEnableVertexAttribArray(1);


	glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNorm)));
	glEnableVertexAttribArray(2);


	glVertexAttribPointer(3, floatsPerTex, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNorm + floatsPerUV)));
	//glEnableVertexAttribArray(3);


	const char * padTex = "images/leather.jpg";
	if (!UCreateTexture(padTex, gTextureId2))
	{
		cout << "Failed to load texture " << padTex << endl;
		return EXIT_FAILURE;
	}
}


void UDestroyMesh3(GLMesh& buttpadMesh)
{
	glDeleteVertexArrays(1, &buttpadMesh.vao);
	glDeleteBuffers(1, &buttpadMesh.vbo);
}



bool UCreateMesh4(GLMesh& backpadMesh)
{

	GLfloat verts[] = {
		// vertex positions    Normals                    textures (s, t)      texture index
		//Triangle 1           (left face: negative x, negative z)
		-0.25f, 0.35f, -0.70f, -0.0175f, 0.0f, -0.0085f,  0.5f, 1.0f,          2.0f,  // V0 
		-0.42f, 0.4f,  0.20f,  -0.0175f, 0.0f, -0.0085f,  1.0f, 0.0f,          2.0f,  // V1 
		-0.42f, 0.35f, 0.20f,  -0.0175f, 0.0f, -0.0085f,  0.0f, 0.0f,          2.0f,  // V2 
		//Triangle 2           (bottom face: negative y, neg z)
		-0.25f, 0.35f, -0.70f, 0.0175f, 0.0f, -0.0085f,   0.5f, 1.0f,          2.0f,  // V0 
		-0.42f, 0.35f, 0.20f,  0.0175f, 0.0f, -0.0085f,   1.0f, 0.0f,          2.0f,  // V2 
		-0.08f, 0.35f, 0.20f,  0.0175f, 0.0f, -0.0085f,   0.0f, 0.0f,          2.0f,  // V3 
		//Triangle 3           (right face: positive x, negative z)
		-0.25f, 0.35f, -0.70f, 0.0175f, 0.0f, -0.0085f,   0.5f, 1.0f,          2.0f,  // V0 
		-0.08f, 0.35f, 0.20f,  0.0175f, 0.0f, -0.0085f,   1.0f, 0.0f,          2.0f,  // V3 
		-0.08f, 0.4f,  0.20f,  0.0175f, 0.0f, -0.0085f,   0.0f, 0.0f,          2.0f,  // V4 
		//Triangle 4           (top face: positive y, neg z)
		-0.25f, 0.35f, -0.70f, 0.0f, 0.119f, -0.017f,     0.5f, 1.0f,          2.0f,  // V0 
		-0.08f, 0.4f,  0.20f,  0.0f, 0.119f, -0.017f,     1.0f, 0.0f,          2.0f,  // V4 
		-0.42f, 0.4f,  0.20f,  0.0f, 0.119f, -0.017f,     0.0f, 0.0f,          2.0f,  // V1 
		//Triangle 5           (front face upper triangle, pos z)
		-0.42f, 0.4f,  0.20f,  0.0f, 0.0f, 0.017f,        0.0f, 1.0f,          2.0f,  // V1 
		-0.42f, 0.35f, 0.20f,  0.0f, 0.0f, 0.017f,        0.0f, 0.0f,          2.0f,  // V2 
		-0.08f, 0.4f,  0.20f,  0.0f, 0.0f, 0.017f,        1.0f, 1.0f,          2.0f,  // V4 
		//Triangle 6           (front face lower triangle, pos z)
		-0.42f, 0.35f, 0.20f,  0.0f, 0.0f,  0.017f,       0.0f, 0.0f,          2.0f,  // V2 
		-0.08f, 0.35f, 0.20f,  0.0f, 0.0f,  0.017f,       1.0f, 1.0f,          2.0f,  // V3 
		-0.08f, 0.4f,  0.20f,  0.0f, 0.0f,  0.017f,       1.0f, 1.0f,          2.0f   // V4 

	};


	const GLuint floatsPerVertex = 3;
	const GLuint floatsPerNorm = 3;
	const GLuint floatsPerUV = 2;
	const GLuint floatsPerTex = 1;


	backpadMesh.nVertices = sizeof(verts) / (sizeof(verts[0]) * (floatsPerVertex + floatsPerNorm + floatsPerUV + floatsPerTex));


	glGenVertexArrays(1, &backpadMesh.vao); // bind to feet VAO
	glBindVertexArray(backpadMesh.vao);  // mesh of one object bound to feet VAO


	// Create VBO
	glGenBuffers(1, &backpadMesh.vbo);
	glBindBuffer(GL_ARRAY_BUFFER, backpadMesh.vbo); // Activates the buffer
	glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU


	// Strides between vertex coordinates is 6 (x, y, z, s, t, i). 
	GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNorm + floatsPerUV + floatsPerTex); // The number of floats before each


	//Create Vertex Attribute Pointers
	glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
	glEnableVertexAttribArray(0);


	glVertexAttribPointer(1, floatsPerNorm, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
	glEnableVertexAttribArray(1);


	glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNorm)));
	glEnableVertexAttribArray(2);


	glVertexAttribPointer(3, floatsPerTex, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNorm + floatsPerUV)));
	//glEnableVertexAttribArray(3);


	const char * padTex = "images/leather.jpg";
	if (!UCreateTexture(padTex, gTextureId))
	{
		cout << "Failed to load texture " << padTex << endl;
		return EXIT_FAILURE;
	}
}


void UDestroyMesh4(GLMesh& backpadMesh)
{
	glDeleteVertexArrays(1, &backpadMesh.vao);
	glDeleteBuffers(1, &backpadMesh.vbo);
}


bool UCreateMesh5(GLMesh& sphereMesh)
{
	
	float radius = 1.0;
	float x, y, z, xy;  // position vertices
	float nx, ny, nz, lengthInv = 1.0f / radius;  // normal vertices  
	float s, t;  // texture vertices
	float p;     // texture index
	int sectorCount = 60;
	int stackCount = 12;

	float sectorStep = 2 * PI / sectorCount;
	float stackStep = PI / stackCount;
	float sectorAngle, stackAngle;
	vector <GLfloat> IndexVect;

	for (int i = 0; i <= stackCount; ++i)
	{
		stackAngle = PI / 2 - i * stackStep;  // starting from pi/2 to -pi/2
		xy = radius * cosf(stackAngle);       // r * cos(u)
		z = radius * sinf(stackAngle);        // r * sin(u)

		// add (sectorCount+1) vertices per stack
		// the first and last vertices have same position and normal, but different tex coords
		for (int j = 0; j <= sectorCount; ++j)
		{
			sectorAngle = j * sectorStep;     // starting from 0 to 2pi

			// vertex position (x, y, z)
			x = xy * cosf(sectorAngle);       // r * cos(u) * cos(v)
			y = xy * sinf(sectorAngle);       // r * cos(u) * sin(v)
			IndexVect.push_back(x);     
			IndexVect.push_back(y);
			IndexVect.push_back(z);
			// normalized vertex normal (nx, ny, nz)
			nx = x * lengthInv;
			ny = y * lengthInv;
			nz = z * lengthInv;
			IndexVect.push_back(nx);
			IndexVect.push_back(ny);
			IndexVect.push_back(nz);
			// vertex tex coord (s, t) range between [0, 1]
			s = (float)j / sectorCount;
			t = (float)i / stackCount;
			IndexVect.push_back(s);
			IndexVect.push_back(t);
			// tex index (p)
			p = 1.0f;
			IndexVect.push_back(p);
		}
	}

	vector <int> indices;
	vector <int> lineIndices;
	int k1, k2;
	for (int i = 0; i < stackCount; ++i)
	{
		k1 = i * (sectorCount + 1);  // beginning of current stack
		k2 = k1 + sectorCount + 1;   // beginning of next stack

		for (int j = 0; j < sectorCount; ++j, ++k1, ++k2)
		{
			// 2 triangles per sector excluding first and last stacks
			// k1 => k2 => k1+1
			if (i != 0)
			{
				indices.push_back(k1);
				indices.push_back(k2);
				indices.push_back(k1 + 1);
			}

			// k1+1 => k2 => k2+1
			if (i != (stackCount - 1))
			{
				indices.push_back(k1 + 1);
				indices.push_back(k2);
				indices.push_back(k2 + 1);
			}

			// store indices for lines
			// vertical lines for all stacks, k1 => k2
			lineIndices.push_back(k1);
			lineIndices.push_back(k2);
			if (i != 0)  // horizontal lines except 1st stack, k1 => k+1
			{
				lineIndices.push_back(k1);
				lineIndices.push_back(k1 + 1);
			}
		}
	}

	const GLuint floatsPerVertex = 3;
	const GLuint floatsPerNorm = 3;
	const GLuint floatsPerUV = 2;
	const GLuint floatsPerTex = 1;

	sphereMesh.nVertices = sizeof(IndexVect) / (sizeof(IndexVect[0]) * (floatsPerVertex + floatsPerNorm + floatsPerUV + floatsPerTex));
	sphereMesh.nIndices = sizeof(indices);

	glGenVertexArrays(1, &sphereMesh.vao); // bind to feet VAO
	glBindVertexArray(sphereMesh.vao);  // mesh of one object bound to feet VAO
	
	// Create VBO
	glGenBuffers(1, &sphereMesh.vbo);
	glBindBuffer(GL_ARRAY_BUFFER, sphereMesh.vbo); // Activates the buffer
	glBufferData(GL_ARRAY_BUFFER, sphereMesh.nVertices, &IndexVect, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

	// Create EBO
	glGenBuffers(1, &sphereMesh.ebo);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, sphereMesh.ebo);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sphereMesh.nIndices, &indices, GL_STATIC_DRAW);
    

	// Strides between vertex coordinates is 9 (x, y, z, nx, ny, nz, s, t, p). 
	GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNorm + floatsPerUV + floatsPerTex); // The number of floats before each


	//Create Vertex Attribute Pointers
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
	

	glEnableVertexAttribArray(1);
	glVertexAttribPointer(1, floatsPerNorm, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
	
	
	glEnableVertexAttribArray(2);
	glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNorm)));
	

	glEnableVertexAttribArray(3);
	glVertexAttribPointer(3, floatsPerTex, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNorm + floatsPerUV)));
	

	
	const char* padTex = "images/leather.jpg";
	if (!UCreateTexture(padTex, gTextureId))
	{
		cout << "Failed to load texture " << padTex << endl;
		return EXIT_FAILURE;
	}
		
}


void UDestroyMesh5(GLMesh& sphereMesh)
{
	glDeleteVertexArrays(1, &sphereMesh.vao);
	glDeleteBuffers(1, &sphereMesh.vbo);
	glDeleteBuffers(1, &sphereMesh.ebo);
}



// Generate and load the texture
bool UCreateTexture(const char* filename, GLuint &textureId)
{
	int width, height, channels;
	unsigned char* image = stbi_load(filename, &width, &height, &channels, 0);
	if (image)
	{
		flipImageVertically(image, width, height, channels);

		glGenTextures(1, &textureId);
		glBindTexture(GL_TEXTURE_2D, textureId);


		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);


		if (channels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		else if (channels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			cout << "Not implemented to handle image with " << channels << " channels" << endl;
			return false;
		}


		    glGenerateMipmap(GL_TEXTURE_2D);


		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture


		return true;
	}


	// Error loading the image
	return false;

}



void UDestroyTexture(GLuint textureId)
{
	glGenTextures(1, &textureId);
}


// Implements the UCreateShaders function
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId)
{
	//Compilation and linkage error reporting
	int success = 0;
	char infoLog[512];


	// Create a Shader program object.
	programId = glCreateProgram();


	// Create the vertex and fragment shader objects
	GLuint vertexShaderId = glCreateShader(GL_VERTEX_SHADER);
	GLuint fragmentShaderId = glCreateShader(GL_FRAGMENT_SHADER);


	// Retrieve the shader source
	glShaderSource(vertexShaderId, 1, &vtxShaderSource, NULL);
	glShaderSource(fragmentShaderId, 1, &fragShaderSource, NULL);


	// Compile the vertex shader, and print compilation errors (if any)
	glCompileShader(vertexShaderId); // compile the vertex shader
	// check for shader compile errors
	glGetShaderiv(vertexShaderId, GL_COMPILE_STATUS, &success);
	if (!success)
	{
		glGetShaderInfoLog(vertexShaderId, 512, NULL, infoLog);
		std::cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << std::endl;


		return false;

	}


	glCompileShader(fragmentShaderId); // compile the fragment shader
	// check for shader compile errors
	glGetShaderiv(fragmentShaderId, GL_COMPILE_STATUS, &success);
	if (!success)
	{
		glGetShaderInfoLog(fragmentShaderId, sizeof(infoLog), NULL, infoLog);
		std::cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << std::endl;


		return false;

	}


	// Attached compiled shaders to the shader program
	glAttachShader(programId, vertexShaderId);
	glAttachShader(programId, fragmentShaderId);


	glLinkProgram(programId);  // links the shader program
	// check for linking errors
	glGetProgramiv(programId, GL_LINK_STATUS, &success);
	if (!success)
	{
		glGetProgramInfoLog(programId, sizeof(infoLog), NULL, infoLog);
		std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;


		return false;

	}


	glUseProgram(programId);  // uses the shader program


	return true;

}


void UDestroyShaderProgram(GLuint programId)
{
	glDeleteProgram(programId);
}



void UpdateProjection(GLboolean toggle)
{
	static GLboolean usePerspective = GL_TRUE;

	// toggle the control variable if needed
	if (toggle)
		usePerspective = !usePerspective;

	// reset the projection matrix
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	// choose projection based on toggle
	if (usePerspective)
	{
		// set to perspective
		glFrustum(-1.0, 1.0, -1.0, 1.0, 5, 100);
	}
	else
	{
		glOrtho(-1.0, 1.0, -1.0, 1.0, 5, 100);
	}

	// reset model view matrix
	glMatrixMode(GL_MODELVIEW);

}


// NOTE: check here for sphere generation: https://stackoverflow.com/questions/5988686/creating-a-3d-sphere-in-opengl-using-visual-c